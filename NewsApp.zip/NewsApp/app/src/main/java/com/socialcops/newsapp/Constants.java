package com.socialcops.newsapp;

public class Constants {

    public final static String API_KEY = "d80f2584a43647a3bc977fd2d3345349";
}
